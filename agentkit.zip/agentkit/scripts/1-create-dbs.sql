CREATE DATABASE fastapi_db;
CREATE DATABASE celery_schedule_jobs;
CREATE DATABASE pdf_indexing_1;
\connect pdf_indexing_1
CREATE EXTENSION vector;
