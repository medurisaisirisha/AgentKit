import { AUTH_SELECTORS } from "~/utils/signin.selectors"

export default {
  ...AUTH_SELECTORS,
}
