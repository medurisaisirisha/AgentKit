export const CHAT_MESSAGES = {
  prompt1: {
    text: "How many artists and songs are there in the database?",
    hasAnHtmlTableComponent: false,
  },
}
