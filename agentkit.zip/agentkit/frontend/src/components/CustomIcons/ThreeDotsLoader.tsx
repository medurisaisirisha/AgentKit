const ThreeDotsLoader = () => <span className="daisyloading daisyloading-dots daisyloading-sm"></span>

export default ThreeDotsLoader
