export interface User {
  id: string
  name: string
  description: string
  avatar: string
}
