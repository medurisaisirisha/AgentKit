export const APPLICATION_TITLE = "AgentKit"
export const LOGO_SRC = "/logo.png"
export const LOGO_FULL_SRC = "/logo_full.png"
export const LOGO_FULL_DARK_SRC = "/logo_full_dark.png"
