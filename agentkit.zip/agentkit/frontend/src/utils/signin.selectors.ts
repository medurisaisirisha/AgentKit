export const AUTH_SELECTORS = {
  emailInput: "authEmailInput",
  passwordInput: "authPasswordInput",
  signinButton: "AuthSignInButton",
}
