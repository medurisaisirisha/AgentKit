/* generated using openapi-typescript-codegen -- do no edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

import type { ExecutionResult } from "./ExecutionResult"

export type IGetResponseBase_ExecutionResult_ = {
  message?: string
  meta?: Record<string, any>
  data: ExecutionResult | null
}
