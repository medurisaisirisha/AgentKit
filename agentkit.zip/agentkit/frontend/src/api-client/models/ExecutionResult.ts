/* generated using openapi-typescript-codegen -- do no edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

export type ExecutionResult = {
  rawResult: Array<Record<string, any>>
  affectedRows?: number | null
  error?: string | null
}
