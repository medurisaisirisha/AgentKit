/* generated using openapi-typescript-codegen -- do no edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

import type { StreamingDataTypeEnum } from "./StreamingDataTypeEnum"

export type StreamingData = {
  data: string
  data_type?: StreamingDataTypeEnum
  metadata?: Record<string, any>
}
