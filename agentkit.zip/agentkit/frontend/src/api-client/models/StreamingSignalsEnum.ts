/* generated using openapi-typescript-codegen -- do no edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

/**
 * Description of your enum
 */
export enum StreamingSignalsEnum {
  START = "START",
  END = "END",
  TOOL_END = "TOOL_END",
  LLM_END = "LLM_END",
}
