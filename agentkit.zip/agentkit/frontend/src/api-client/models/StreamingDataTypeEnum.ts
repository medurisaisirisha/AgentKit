/* generated using openapi-typescript-codegen -- do no edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

/**
 * Description of your enum
 */
export enum StreamingDataTypeEnum {
  TEXT = "text",
  LLM = "llm",
  APPENDIX = "appendix",
  ACTION = "action",
  SIGNAL = "signal",
}
