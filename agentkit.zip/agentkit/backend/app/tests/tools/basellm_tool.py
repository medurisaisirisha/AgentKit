# -*- coding: utf-8 -*-
from unittest.mock import patch

import pytest
from langchain.base_language import BaseLanguageModel

from app.schemas.agent_schema import AgentConfig
from app.services.chat_agent.tools.library.basellm_tool.basellm_tool import BaseLLM


@pytest.fixture(autouse=True)
def mock_llm_call(llm: BaseLanguageModel):  # pylint: disable=redefined-outer-name
    with patch("app.services.chat_agent.tools.library.basellm_tool.basellm_tool.get_llm", return_value=llm):
        yield


@pytest.fixture
def basellm_tool(agent_config: AgentConfig) -> BaseLLM:
    basellm_tool = BaseLLM.from_config(
        config=agent_config.tools_library.library["expert_tool"], common_config=agent_config.common
    )
    return basellm_tool


@pytest.mark.asyncio
async def test_basellm_tool_run(basellm_tool: BaseLLM, tool_input: str):
    query = tool_input
    output = await basellm_tool._arun(query)

    assert output == "0"

async def _arun(
        self,
        *args: Any,
        run_manager: Optional[AsyncCallbackManagerForToolRun] = None,
        **kwargs: Any,
    ) -> str:
        """Use the tool asynchronously."""
        try:
            query = kwargs.get(
                "query",
                args[0],
            )
            tool_input = ToolInputSchema.parse_raw(query)
            user_question = tool_input.latest_human_message

            data = tool_input.intermediate_steps["sql_tool"]

            messages = [
                SystemMessage(content=self.system_context),
                HumanMessage(content=self.prompt_message.format(question=user_question, retrieved_data=data))
            ]
            response = await self._agenerate_response(messages, discard_fast_llm=True, run_manager=run_manager)

            logger.info(f"Expert Tool response - {response}")

            return response
        except Exception as e:
            if run_manager is not None:
                await run_manager.on_tool_error(e, tool=self.name)
                return repr(e)
            raise e
